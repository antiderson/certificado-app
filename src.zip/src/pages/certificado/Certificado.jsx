import DropdownSelect from '../../components/dropdown/DropdownSelect';
import styles from './index.module.css';
import EspecialidadeCertificate from '../../components/especialidadeCertificate/EspecialidadeCertificate';


export default function Certificado() {
    return (
        <div className={styles.container}>
            <DropdownSelect />
            {/* <EspecialidadeCertificate /> */}
        </div>
    )
}