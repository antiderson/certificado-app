import Header from "../../components/header/Header";

export default function Registros() {
    return (
        <div>
            {/* <Header /> */}
        </div>
    )
}